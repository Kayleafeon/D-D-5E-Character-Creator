package net.amber.culminating;

public interface Spell { //unused
    int getSpellLevel();
    String getSpellName();
    String getSpellDescription();
    String getTarget();
    int getDmgOrHealing();
    String getCastTime();
    int getRange();
    String getDuration();
}
