package net.amber.culminating;

public class FightingStyle {
    private String name;
    private String desc;
    public FightingStyle(String n, String d) {
        name = n;
        desc = d;
    }
    public String getName() {
        return name;
    }
    public String getDesc() {
        return desc;
    }
}
