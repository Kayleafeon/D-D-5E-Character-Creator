package net.amber.culminating;

public interface Spellcaster { //unused
    int getSpellSlots();
    String getCasterType();
    String getSpellList();
    String getSpells();
}
